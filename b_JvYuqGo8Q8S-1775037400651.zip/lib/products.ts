export interface Product {
  id: string
  name: string
  description: string
  priceInCents: number
}

export const PRODUCTS: Product[] = [
  {
    id: 'nft-auto-generation',
    name: 'NFT Revenue Engine - Geração Automática',
    description: 'Acesso completo ao gerador automático de NFTs com IA',
    priceInCents: 1900, // $19.00
  },
]
