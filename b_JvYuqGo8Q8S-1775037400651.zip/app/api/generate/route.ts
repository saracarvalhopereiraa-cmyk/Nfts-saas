import { generateText, Output } from 'ai'
import { z } from 'zod'

const nftSchema = z.object({
  name: z.string().describe('Nome criativo e atraente para o NFT'),
  revenuePotential: z.string().describe('Potencial de receita mensal em dólares (ex: $500-$2000)'),
  targetAudience: z.string().describe('Público-alvo ideal para este NFT'),
  salesStrategy: z.string().describe('Estratégia de vendas recomendada'),
  suggestedPrice: z.string().describe('Preço sugerido em dólares'),
})

export async function POST(req: Request) {
  const { idea } = await req.json()

  if (!idea || typeof idea !== 'string') {
    return Response.json({ error: 'Ideia é obrigatória' }, { status: 400 })
  }

  const { output } = await generateText({
    model: 'openai/gpt-4o-mini',
    output: Output.object({
      schema: nftSchema,
    }),
    messages: [
      {
        role: 'system',
        content: `Você é um especialista em NFTs e monetização digital. Analise a ideia do usuário e gere uma proposta de NFT lucrativa e realista. Seja específico e criativo. Responda sempre em português brasileiro.`,
      },
      {
        role: 'user',
        content: `Gere uma proposta de NFT lucrativa baseada nesta ideia: "${idea}"`,
      },
    ],
  })

  return Response.json({ nft: output })
}
