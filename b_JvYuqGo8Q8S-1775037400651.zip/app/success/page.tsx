import { CheckCircle, ArrowRight, Gem } from 'lucide-react'
import Link from 'next/link'

export default function SuccessPage() {
  return (
    <main className="min-h-screen bg-background flex items-center justify-center">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent pointer-events-none" />
      
      <div className="relative container mx-auto px-4">
        <div className="max-w-lg mx-auto text-center">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center h-20 w-20 rounded-full bg-accent/20 border border-accent/30 mb-6">
              <CheckCircle className="h-10 w-10 text-accent" />
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Pagamento confirmado
            </h1>
            
            <p className="text-lg text-muted-foreground mb-2">
              Seu acesso foi liberado
            </p>
            
            <p className="text-muted-foreground">
              Agora você tem acesso completo ao NFT Revenue Engine com geração automática ilimitada.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-card border border-border mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center">
                <Gem className="h-5 w-5 text-primary" />
              </div>
              <span className="font-semibold text-foreground">NFT Revenue Engine Pro</span>
            </div>
            
            <ul className="text-sm text-muted-foreground space-y-2 text-left">
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-accent shrink-0" />
                <span>Geração ilimitada de NFTs com IA</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-accent shrink-0" />
                <span>Análise de mercado em tempo real</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-accent shrink-0" />
                <span>Estratégias de vendas personalizadas</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-accent shrink-0" />
                <span>Suporte prioritário</span>
              </li>
            </ul>
          </div>

          <Link
            href="/"
            className="inline-flex items-center gap-2 h-12 px-8 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-semibold transition-all"
          >
            <span>Começar a gerar NFTs</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </main>
  )
}
