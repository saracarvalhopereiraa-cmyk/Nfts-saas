import { NFTGenerator } from '@/components/nft-generator'
import { Gem, TrendingUp, Zap } from 'lucide-react'

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent pointer-events-none" />
      
      <div className="relative">
        <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-40">
          <div className="container mx-auto px-4 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <Gem className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg text-foreground">NFT Revenue Engine</span>
            </div>
          </div>
        </header>

        <section className="container mx-auto px-4 py-16 md:py-24">
          <div className="text-center max-w-4xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm font-medium mb-6">
              <Zap className="h-4 w-4" />
              <span>Powered by AI</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
              Gere seus NFTs{' '}
              <span className="text-primary">automaticamente</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
              Crie, valide e venda NFTs com potencial real de gerar renda mensal em dólar.
            </p>
          </div>

          <NFTGenerator />
        </section>

        <section className="border-t border-border/50 bg-card/50">
          <div className="container mx-auto px-4 py-16">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center p-6 rounded-2xl bg-background border border-border">
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Geração com IA</h3>
                <p className="text-sm text-muted-foreground">
                  Nossa IA analisa o mercado e gera NFTs com alto potencial de receita.
                </p>
              </div>
              
              <div className="text-center p-6 rounded-2xl bg-background border border-border">
                <div className="h-12 w-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-6 w-6 text-accent" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Renda Recorrente</h3>
                <p className="text-sm text-muted-foreground">
                  Estratégias validadas para gerar até $2.000/mês com seus NFTs.
                </p>
              </div>
              
              <div className="text-center p-6 rounded-2xl bg-background border border-border">
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Gem className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Premium Quality</h3>
                <p className="text-sm text-muted-foreground">
                  NFTs únicos e exclusivos criados especialmente para seu nicho.
                </p>
              </div>
            </div>
          </div>
        </section>

        <footer className="border-t border-border/50 py-8">
          <div className="container mx-auto px-4 text-center">
            <p className="text-sm text-muted-foreground">
              NFT Revenue Engine. Todos os direitos reservados.
            </p>
          </div>
        </footer>
      </div>
    </main>
  )
}
