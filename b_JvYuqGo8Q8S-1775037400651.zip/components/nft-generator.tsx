'use client'

import { useState } from 'react'
import { Rocket, Zap } from 'lucide-react'
import { NFTResultCard } from './nft-result-card'
import { LoadingSpinner } from './loading-spinner'
import { CheckoutModal } from './checkout-modal'

interface NFTResult {
  name: string
  revenuePotential: string
  targetAudience: string
  salesStrategy: string
  suggestedPrice: string
}

export function NFTGenerator() {
  const [idea, setIdea] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<NFTResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)

  const handleGenerate = async () => {
    if (!idea.trim()) return

    setIsLoading(true)
    setError(null)
    setResult(null)

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea }),
      })

      if (!response.ok) {
        throw new Error('Falha ao gerar NFT')
      }

      const data = await response.json()
      setResult(data.nft)
    } catch (err) {
      setError('Ocorreu um erro. Tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto mb-8">
        <input
          type="text"
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="Ex: comunidade VIP de traders"
          className="flex-1 h-14 px-5 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
          onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
        />
        <button
          onClick={handleGenerate}
          disabled={isLoading || !idea.trim()}
          className="h-14 px-8 rounded-xl bg-primary hover:bg-primary/90 text-primary-foreground font-semibold flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed animate-pulse-glow"
        >
          <Zap className="h-5 w-5" />
          <span>Gerar NFT lucrativo</span>
        </button>
      </div>

      {error && (
        <div className="max-w-2xl mx-auto mb-8 p-4 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive text-center">
          {error}
        </div>
      )}

      {isLoading && <LoadingSpinner />}

      {result && !isLoading && (
        <div className="space-y-8 animate-in fade-in duration-500">
          <NFTResultCard nft={result} />
          
          <div className="flex justify-center">
            <button
              onClick={() => setIsCheckoutOpen(true)}
              className="h-14 px-10 rounded-xl bg-accent hover:bg-accent/90 text-accent-foreground font-bold text-lg flex items-center gap-3 transition-all hover:scale-105"
            >
              <Rocket className="h-6 w-6" />
              <span>Ativar geração automática ($19)</span>
            </button>
          </div>
        </div>
      )}

      <CheckoutModal
        productId="nft-auto-generation"
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
      />
    </div>
  )
}
