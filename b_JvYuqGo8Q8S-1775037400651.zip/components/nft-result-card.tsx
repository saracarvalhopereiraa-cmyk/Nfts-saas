'use client'

import { Sparkles, Target, TrendingUp, DollarSign, Users } from 'lucide-react'

interface NFTResult {
  name: string
  revenuePotential: string
  targetAudience: string
  salesStrategy: string
  suggestedPrice: string
}

export function NFTResultCard({ nft }: { nft: NFTResult }) {
  return (
    <div className="w-full max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-6 md:p-8">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        
        <div className="relative">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/20">
              <Sparkles className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">NFT Gerado</p>
              <h3 className="text-xl font-bold text-foreground">{nft.name}</h3>
            </div>
          </div>

          <div className="grid gap-4">
            <div className="flex items-start gap-3 rounded-xl bg-accent/10 p-4 border border-accent/20">
              <TrendingUp className="h-5 w-5 text-accent mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-accent">Potencial de Receita</p>
                <p className="text-lg font-bold text-foreground">{nft.revenuePotential}/mês</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl bg-secondary p-4">
              <Users className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Público-alvo</p>
                <p className="text-foreground">{nft.targetAudience}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl bg-secondary p-4">
              <Target className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Estratégia de Vendas</p>
                <p className="text-foreground">{nft.salesStrategy}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-xl bg-primary/10 p-4 border border-primary/20">
              <DollarSign className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-primary">Preço Sugerido</p>
                <p className="text-lg font-bold text-foreground">{nft.suggestedPrice}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
